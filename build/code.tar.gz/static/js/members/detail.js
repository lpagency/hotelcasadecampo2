$(document).ready(function()
{

    // $(".centered-image").each(function()
    // {
    //     var $canvas = $(this).parent();
    //     var $image = $(this);

    //     var canvas_size = [parseInt($canvas.css("width").replace("px", "")), 
    //                     parseInt($canvas.css("height").replace("px", ""))];
    //     var image_size = [$image[0].naturalWidth,
    //                     $image[0].naturalHeight];

    //     var transform = $.me.getTransform(canvas_size, image_size);

    //     $image.css("width", transform[0] + "px");
    //     $image.css("height", transform[1] + "px");
    //     $image.css("margin-left", transform[2] + "px");
    //     $image.css("margin-top", transform[3] + "px");
    // });
});